---
Name: 
Owned By: 
tags: 
Aliasses: 
Rarity:
---
## 🏺 Basic Info
- **Type:** (Weapon, armor, potion, artifact, mundane item, etc.)  
- **Rarity:** (Common, Uncommon, Rare, Legendary, Artifact)  
- **Material:**  
- **Size & Weight:**  
- **Current Owner/Location:** [[ ]]  

## 🔮 Description
> *(A detailed description of what the item looks like, any markings, or special craftsmanship.)*  

## ⚡ Magical Properties (If Any)
- **Effect:**  
- **Activation Method:**  
- **Drawbacks/Limitations:**  
- **Recharge/Uses:**  

## 📖 History & Lore
- **Created By:** [[ ]]  
- **Notable Past Owners:** [[ ]]  
- **Legendary Stories or Myths:**  

## 🕰️ Where It Appears in the Story
- **First Introduced In:** [[ ]]  
- **Major Events Involving This Item:** [[ ]]  

## 🔗 Related Entries
- **Connected Characters:** [[ ]]  
- **Tied Locations:** [[ ]]  
- **Other Similar Items:** [[ ]]  
