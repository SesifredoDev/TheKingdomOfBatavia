---
Title: Session {{Number}} - Title
tags:
  - session
---


## 📍 Location & Timeline
- **Where it took place:** [[ ]]  
- **Current In-Game Date:**  

## 🧑‍🤝‍🧑 Players Present
- **PCs:** [[ ]]  
- **Notable NPCs:** [[ ]]  

## 🎭 Summary of Events
> *(Summarize the key events, interactions, battles, or decisions.)*  

## ⚔️ Combat Encounters (If Any)
- **Enemies Fought:** [[ ]]  
- **Notable Moves/Abilities Used:**  
- **Outcome:**  

## 🔮 Items & Rewards
- **Gold/Wealth Gained:**  
- **New Magic Items:** [[ ]]  
- **Other Notable Loot:**  

## 🌍 Story & World Impact
- **Important NPCs Met:** [[ ]]  
- **Factions Influenced:** [[ ]]  
- **Major Decisions & Their Consequences:**  

## 📝 Session Notes & DM Thoughts
> *(Anything the DM should remember for next time: loose threads, foreshadowing, player plans.)*  

## 🔗 Related Entries
- **Next Steps:** [[ ]]  
- **Unresolved Plot Points:** [[ ]]  
