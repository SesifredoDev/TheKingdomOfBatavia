---
Title: 
tags:
  - Magic
Aliasses: 
Faction:
---

## 🪄 Overview
- **Type:** (Spell, artifact, natural phenomenon, etc.)
- **Effect:**  
- **Rarity:**  

## 📖 Description
> *(What does it look like? How is it used? Any special properties?)*  

## ⚡ Origin & History
- **Created By:** [[ ]]  
- **First Appearance:**  
- **Notable Users:** [[ ]]  

## 🕰️ Current Status
- **Where Is It Now?**  
- **Who Controls It?**  

## 🔗 Related Topics
- **Similar Items:** [[ ]]
- **Connected Characters:** [[ ]]
- **Major Events:** [[ ]]
