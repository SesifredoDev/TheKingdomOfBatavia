---
Title: 
Aliasses: 
tags:
  - lore
Origin:
---

## 🏛️ Overview
- **Type:** (Myth, legend, prophecy, cultural belief)
- **Origin:** (Which culture/place does this come from?)  

## 📖 The Story
> *(Summarize the legend, myth, or belief system.)*  

## 🔥 Influence on the World
- **How Do People Interpret It?**  
- **How Does It Affect Society, Religion, or Magic?**  

## 🔗 Related Topics
- **Locations:** [[ ]]
- **Characters:** [[ ]]
- **Events:** [[ ]]