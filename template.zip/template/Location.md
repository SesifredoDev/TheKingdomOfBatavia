---
Name: 
Type: 
tags:
  - location
---
## 📍 Basic Info 
- **Type:** (City, ruin, kingdom, etc.)
- **Region:** [[ ]]  
- **Notable Residents:** [[ ]]  
- **Affiliated Factions:** [[ ]]  

## 🏙️ Description
> *(Describe the geography, climate, architecture, or important landmarks.)*  

## 🕰️ History
- **Founding/Mythology:**  
- **Major Events:** [[ ]]  
- **Current Status:** (Prosperous, war-torn, abandoned, etc.)  

## 🌟 Key Locations
- **Tavern/Inn:** [[ ]]  
- **Temple/Shrine:** [[ ]]  
- **Market/District:** [[ ]]  

## 🔗 Related Entries
- **Connected Characters:** [[ ]]
- **Important Items:** [[ ]]
- **Story Arcs:** [[ ]]

## 🗺️  Map
