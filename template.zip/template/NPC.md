---
Name: 
tags:
  - character
  - npc
Aliasses: 
Origin / Found: 
Relationship w/  Group:
---
## 🏛️ Basic Info
- **Role:** (e.g., merchant, noble, villain)
- **Race:**  
- **Age:**  
- **Affiliation:** [[ ]]  
- **Location:** [[ ]]  

## 🎭 Personality & Motivations
- **Core Traits:**  
- **Flaws & Secrets:**  
- **What Do They Want?**  

## 📖 Backstory & Role in the Story
> *(Summarize their past and how they influence the plot.)*  

## 🔗 Relationships
- **Connected Characters:** [[ ]]
- **Enemies/Rivals:** [[ ]]
- **Factions:** [[ ]]

## 📝 Notes
> *(Miscellaneous details that might be useful later.)*  
