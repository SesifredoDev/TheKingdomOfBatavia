---
Title: 
tags:
  - "#faction"
Aliasses: 
Origin: 
Relationship w/  Group:
---

## 🏛️ Basic Info
- **Type:** (Guild, kingdom, cult, secret society, etc.)
- **Purpose/Mission:**  
- **Headquarters:** [[ ]]  
- **Notable Members:** [[ ]]  
- **Allies/Rivals:** [[ ]]  

## 📖 History
- **Founding Story:**  
- **Major Conflicts/Involvements:**  
- **Current Status:**  

## 🔗 Related Topics
- **Leaders:** [[ ]]
- **Key Locations:** [[ ]]
- **Artifacts:** [[ ]]