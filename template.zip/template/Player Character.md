---
Name: Player Character
tags:
  - character
  - pc
Aliasses:
  - Barbra
  - Steve
Origin:
---
## 🧑‍🎤 Overview
- **Full Name:** 
- **Race:**  
- **Class:**  
- **Alignment:**  
- **Age:**  
- **Background:**  

## 🎭 Personality & Motivation
- **Core Traits:**  
- **Flaws & Weaknesses:**  
- **Personal Goals:**  

## ⚔️ Combat & Skills
- **Primary Fighting Style:**  
- **Notable Abilities:**  
- **Weapons & Gear:**  

## 📖 Backstory
> *(Summary of their past, important events, and how it affects their journey.)*  

## 🕸️ Relationships
- **Allies:** [[ ]]
- **Rivals/Enemies:** [[ ]]
- **Organizations:** [[ ]]

%% ## 🔗 Key Events
- [[Timeline]] | [[Major Arc]]   %%
