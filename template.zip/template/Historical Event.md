---
Name: 
tags:
  - History
Aliasses: 
Location:
---


## 📆 Date & Timeframe
- **Year/Era:**  
- **Duration:**  

## 🏛️ Overview
- **Type of Event:** (War, revolution, disaster, discovery, etc.)
- **Key People Involved:** [[ ]]  

## 📖 What Happened?
> *(Summarize the major events in a narrative format.)*  

## 🌍 Consequences & Legacy
- **How Did This Change the World?**  
- **Who Benefited or Suffered?**  

## 🔗 Related Entries
- **Factions Involved:** [[ ]]
- **Key Locations:** [[ ]]
- **Major Battles/Incidents:** [[ ]]
